﻿using DotNet.Utilities;
using DotNet.Utilities.MQ;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace DotNet.RabbitMQ
{

    /// <summary>
    ///  RabbitMQ 的消费客户端实现。
    /// 
    /// 
    /// 修改记录
    ///     2016.09.29 版本：1.0    刘海洋
    ///	
    /// <author>
    ///		<name>刘海洋</name>
    ///		<date>2016.09.29</date>
    /// </author> 
    /// </summary>
    public class RabbitConsumerClient : IConsumerClient
    {
        private string _ServerAddr = "";
        private int _ServerPort = 0;
        private string _ConsumerId = "";
        private string _Topices = "";
        private string _FilterKeys = "";
        private string _AccessKey = "";
        private string _SecretKey = "";
        private string _QueueName = "";

        /// <summary>
        /// 消息过期时间。
        /// </summary>
        private long _MessageExpTime = 0;

        /// <summary>
        /// 消息处理方法回调。
        /// </summary>
        private MessageProcessCallback _MessageProcessCallback = null;

        private ConnectionFactory _Factory = null;
        private IConnection _Connection = null;
        /// <summary>
        /// 消息订阅通道，每个消息主题可以有多个通道（受最大线程数参数控制）。
        /// </summary>
        private Dictionary<string,List<IModel>> _Channels = new Dictionary<string, List<IModel>>();
        /// <summary>
        /// 每个消息主题的二级过滤内容。
        /// </summary>
        private Dictionary<string,string[]> _TopiceFilters = new Dictionary<string, string[]>();

        /// <summary>
        /// 消息交换类型。
        /// </summary>
        private string _ExchangeType = "";

        /// <summary>
        /// 任务取消控制器。
        /// </summary>
        private CancellationTokenSource _TaskTokenSource = new CancellationTokenSource();

        /// <summary>
        /// 最大的消费者线程数。
        /// </summary>
        private int _MaxConsumerThreads = 4;

        /// <summary>
        /// 释放资源。
        /// </summary>
        public void Dispose()
        {
            Shutdown();

            _Factory = null;
            _TopiceFilters.Clear();
        }

        /// <summary>
        /// 设置消息队列的连接信息。
        /// </summary>
        /// <param name="serverAddr">服务器地址。</param>
        /// <param name="serverPort">端口号。</param>
        /// <param name="consumerId">消费者Id。</param>
        /// <param name="accessKey">用户名。</param>
        /// <param name="secretKey">密码。</param>
        /// <param name="maxConsumerThreads">最大消费者线程数。</param>
        public void SetConnectInfo(string serverAddr = "",int serverPort = 0, string consumerId = "", 
            string accessKey = "", string secretKey = "",int maxConsumerThreads = 4)
        {
            _ServerAddr = serverAddr;
            _ConsumerId = consumerId;
            _AccessKey = accessKey;
            _SecretKey = secretKey;
            _ServerPort = serverPort;
            _MaxConsumerThreads = maxConsumerThreads;
        }

        /// <summary>
        /// 与服务器是否处于连接状态。
        /// </summary>
        /// <returns>true:已连接，false:未连接。</returns>
        public bool IsConnected()
        {
            bool isConnect = false;
            if (_Connection != null)
                isConnect = _Connection.IsOpen;
            return isConnect;
        }

        /// <summary>
        /// 开始接收指定消息队列的消息。。
        /// </summary>
        /// <param name="queueName">要消费的消息队列的名称。</param>
        /// <param name="mpc">消息处理回调函数。</param>
        public void StartConsumer(string queueName, MessageProcessCallback mpc)
        {
            _QueueName = queueName;
            _MessageProcessCallback = mpc;

            if (mpc == null)
                throw new Exception("必须指定 mpc 参数。");

            if (_Factory == null)
            {
                _Channels.Clear();
                _Factory = new ConnectionFactory() { HostName = _ServerAddr, Port = _ServerPort, VirtualHost = string.IsNullOrEmpty(_ConsumerId) ? "/": _ConsumerId, UserName = _AccessKey, Password = _SecretKey };
                //网络连接异常时自动恢复。
                _Factory.AutomaticRecoveryEnabled = true;
                //每10秒钟检查一次网络连接。
                _Factory.NetworkRecoveryInterval = new TimeSpan(0, 0, 10);
                _Factory.RequestedHeartbeat = 60; //心跳检测超时时间，60秒。
                _Connection = _Factory.CreateConnection();

                IModel mainChannel = null;
                if (!_Channels.ContainsKey(_QueueName))
                {
                    mainChannel = _Connection.CreateModel();
                    //每个消费者同一时间最多分发100条消息。
                    mainChannel.BasicQos(0, 100, true);
                    _Channels.Add(_QueueName, new List<IModel>());
                }

                //一个线程对应一个消息通道。
                _Channels[_QueueName].Add(mainChannel);
                for (int ti = 1; ti < _MaxConsumerThreads; ti++)
                {
                    IModel childChanel = _Connection.CreateModel();
                    childChanel.BasicQos(0, 100, true);
                    _Channels[_QueueName].Add(childChanel);                   
                }

                foreach(IModel channel in _Channels[_QueueName])
                {
                    var consumer = new EventingBasicConsumer(channel);
                    consumer.Received += (model, ea) =>
                    {
                        MessageProcess(channel, ea.Body, ea.ConsumerTag, ea.RoutingKey, ea.BasicProperties.MessageId,
                            ea.DeliveryTag, _MessageProcessCallback);
                    };

                    channel.BasicConsume(queue: queueName,
                                     noAck: false,
                                     consumer: consumer);
                }
            }
        }

        /// <summary>
        /// 开始接收Topice方式推送的消息。
        /// </summary>
        /// <param name="topices">要消费的消息队列标志，可以多个,多个之间以"||"分隔</param>
        /// <param name="filterKeys">对消费的消息队列进行二次过滤，与<paramref name="topices"/>一一对应，以"||"分隔，如果要单个队列使用多个过滤条件，过滤条件之间使用","分隔。
        /// 都不过滤使用"*"或传空字符。</param>
        /// <param name="mpc">消息处理回调函数，把你处理消息的函数传进来。</param>
        /// <param name="expTime">消息有效时间，毫秒。默认为三天，过期自动删除。</param>
        public void StartTopiceConsumer(string topices, string filterKeys, MessageProcessCallback mpc, long expTime = 259200000)
        {
            StartConsumer(topices, filterKeys, "topic", mpc, expTime);
        }

        /// <summary>
        /// 开始接收发布订阅方式推送的消息。
        /// </summary>
        /// <param name="topices">要消费的消息队列标志，可以多个,多个之间以"||"分隔</param>
        /// <param name="mpc">消息处理回调函数，把你处理消息的函数传进来。</param>
        /// <param name="expTime">消息有效时间，毫秒。默认为三天，过期自动删除。</param>
        public void StartPubSubConsumer(string topices, MessageProcessCallback mpc, long expTime = 259200000)
        {
            StartConsumer(topices, "", "fanout", mpc, expTime);
        }

        /// <summary>
        /// 开始消费（订阅）指定的消息。
        /// </summary>
        /// <param name="topices">要消费的消息队列标志，可以多个,多个之间以"||"分隔</param>
        /// <param name="filterKeys">对消费的消息队列进行二次过滤，与<paramref name="topices"/>一一对应，以"||"分隔，如果要单个队列使用多个过滤条件，过滤条件之间使用","分隔。
        /// 都不过滤使用"*"或传空字符。</param>
        /// <param name="mpc">消息处理回调函数，把你处理消息的函数传进来。</param>
        /// <param name="exchangeType">消息交换类型。"topic"：主题模式，支持多级过滤；"fanout"，发布/订阅模式，不支持再次过滤。</param>
        /// <param name="expTime">消息有效时间，毫秒。默认为三天，过期自动删除。</param>
        private void StartConsumer(string topices, string filterKeys, string exchangeType, MessageProcessCallback mpc, long expTime = 259200000)
        {
            _Topices = topices;
            _TopiceFilters.Clear();
            _FilterKeys = filterKeys;
            _MessageProcessCallback = mpc;
            _ExchangeType = exchangeType;
            _MessageExpTime = expTime;


            if (mpc == null)
                throw new Exception("必须指定 mpc 参数。");

            string[] theTopices = _Topices.Split("||".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
            if (theTopices.Length < 1)
                throw new Exception("必须指定 topice 参数。");

            if (string.IsNullOrEmpty(_FilterKeys) && exchangeType.Equals("topic"))
            {
                //如果没有指定子过滤内容并且消息接收方式为"topic"，则默认接收所有消息。
                _FilterKeys = "*";
            }

            if (_FilterKeys != "*")
            {
                if (!string.IsNullOrEmpty(_FilterKeys))
                {
                    //如果有指定二次过滤，必须与topices保持一一对应关系。
                    string[] express = _FilterKeys.Split("||".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
                    if (express.Length != _Topices.Length)
                        throw new Exception("subExpress 参数的||数量必须与 topices 参数一致");
                    foreach (string top in theTopices)
                    {
                        _TopiceFilters.Add(top, express);
                    }
                }
            }
            else
            {
                //订阅所有Topice
                foreach (string top in theTopices)
                {
                    _TopiceFilters.Add(top, new string[] { "#" });
                }
            }

            if (_Factory == null)
            {
                _Channels.Clear();
                _Factory = new ConnectionFactory() { HostName = _ServerAddr, Port = _ServerPort, VirtualHost = _ConsumerId, UserName = _AccessKey, Password = _SecretKey };
                //网络连接异常时自动恢复。
                _Factory.AutomaticRecoveryEnabled = true;
                //每10秒钟检查一次网络连接。
                _Factory.NetworkRecoveryInterval = new TimeSpan(0, 0, 10);
                _Factory.RequestedHeartbeat = 60; //心跳检测超时时间，60秒。
                _Connection = _Factory.CreateConnection();
                //订阅指定的Topice
                foreach (string top in theTopices)
                {
                    IModel mainChannel = null;
                    if (!_Channels.ContainsKey(top))
                    {
                        mainChannel = _Connection.CreateModel();
                        //mainChannel.ExchangeDeclare(exchange: top, type: exchangeType, durable: true);
                        //每个消费者同一时间最多分发10条消息。
                        mainChannel.BasicQos(0, 100, true);
                        _Channels.Add(top, new List<IModel>());
                    }

                    //一个线程对应一个消息通道。
                    _Channels[top].Add(mainChannel);
                    for (int ti = 1; ti < _MaxConsumerThreads; ti++)
                    {
                        IModel childChanel = _Connection.CreateModel();
                        childChanel.BasicQos(0, 100, true);
                        _Channels[top].Add(childChanel);
                    }
                }
            }

            StartConsumerTasks();
        }

        /// <summary>
        /// 启动所有的消费任务。
        /// </summary>
        private void StartConsumerTasks()
        {
            foreach (KeyValuePair<string, List<IModel>> kvpChannel in _Channels)
            {
                List<IModel> channels = kvpChannel.Value;
                foreach (IModel channel in channels)
                {
                    string topic = kvpChannel.Key;
                    string queueName = string.Format("que_{0}_{1}", _AccessKey, topic);
                    Dictionary<string, object> args = new Dictionary<string, object>();
                    args.Add("x-message-ttl", _MessageExpTime); //消息过期时间，毫秒.
                    args.Add("x-queue-mode", "lazy"); //延时队列，消费者离线或消费速度慢时，消息直接写入磁盘，不写内存，读的时候批次从磁盘读。

                    //channel.QueueDeclare(queue: queueName, durable: true, autoDelete: false, exclusive: false, arguments: args);
                    //if (_TopiceFilters.Count > 0)
                    //{
                    //    foreach (var filterKey in _TopiceFilters[topic])
                    //    {
                    //        channel.QueueBind(queue: queueName,
                    //                          exchange: topic,
                    //                          routingKey: filterKey);
                    //    }
                    //}
                    //else
                    //{
                    //    channel.QueueBind(queue: queueName,
                    //                          exchange: topic,
                    //                          routingKey: "");
                    //}

                    var consumer = new EventingBasicConsumer(channel);
                    consumer.Received += (model, ea) =>
                    {
                        MessageProcess(channel, ea.Body, ea.ConsumerTag, ea.RoutingKey, ea.BasicProperties.MessageId,
                            ea.DeliveryTag, _MessageProcessCallback);
                    };

                    channel.BasicConsume(queue: queueName,
                                     noAck: false,
                                     consumer: consumer);
                    //Task consumerTask = new Task((IModel) =>
                    //{
                    //    while (true)
                    //    {
                    //        try
                    //        {
                    //            BasicGetResult bgr = channel.BasicGet(queueName, false);
                    //            if (bgr != null)
                    //            {
                    //                MessageProcess(channel, bgr.Body, queueName, bgr.RoutingKey,
                    //                    bgr.BasicProperties.MessageId, bgr.DeliveryTag, _MessageProcessCallback);
                    //                if (bgr.MessageCount <= 0)
                    //                {
                    //                    //没有消息，休眠。
                    //                    Thread.Sleep(100);
                    //                }
                    //            }
                    //            else
                    //            {
                    //                //没有消息，休眠。
                    //                Thread.Sleep(100);
                    //            }
                    //        }
                    //        catch (Exception ep)
                    //        {
                    //            LogUtilities.WriteException(ep);
                    //            //如果发生异常，休眠3000毫秒再继续。
                    //            Thread.Sleep(3000);
                    //        }
                    //    }

                    //}, channel, _TaskTokenSource.Token, TaskCreationOptions.LongRunning);

                    //consumerTask.Start();
                }
            }
        }

        private void MessageProcess(IModel channel,byte[] msgBody,string consumerTag,string routingKey,
            string msgId,ulong deliveryTag, MessageProcessCallback mpc)
        {
            MessageContent mc = new MessageContent();
            Acks ack = Acks.CommitMessage;
            try
            {
                var body = msgBody;
                string message = Encoding.UTF8.GetString(body);
                mc.MessageBody = message;
                mc.TopicFlag = consumerTag;
                mc.Topic = routingKey;
                mc.MessageID = msgId;
                mc.MessageKey = msgId;
                ack = mpc(mc);

            }
            catch (Exception ep)
            {
                ack = Acks.RejectLater;
                LogUtilities.Log.Error("消息接收出现异常，异常为:{0}，消息内容为：{1}。", ep, mc);
            }
            finally
            {
                switch (ack)
                {
                    case Acks.CommitMessage:
                        //确认消息已处理完成，服务端可以删除。
                        channel.BasicAck(deliveryTag, false);
                        break;
                    case Acks.ReconsumeLater:
                        ////处理失败的消息，需要重新放回队列，重新推送。
                        channel.BasicNack(deliveryTag, false, true);
                        break;
                    case Acks.RejectLater:
                        //处理失败的消息，需要重新放回队列，推送给其它消费者。
                        channel.BasicReject(deliveryTag, true);
                        break;
                    default:
                        break;
            }
            }
        }

        /// <summary>
        /// 暂停接收消息。
        /// </summary>
        public void Pause()
        {
            if(!_TaskTokenSource.IsCancellationRequested)
                _TaskTokenSource.Cancel(false);
        }

        /// <summary>
        /// 继续接收消息。
        /// </summary>
        public void Resume()
        {
            StartConsumerTasks();
        }

        /// <summary>
        /// 关闭所有连接，停止接收消息。
        /// </summary>
        public void Shutdown()
        {
            if (!_TaskTokenSource.IsCancellationRequested)
                _TaskTokenSource.Cancel(false);

            if (_Channels != null)
            {
                foreach (KeyValuePair<string, List<IModel>> kvp in _Channels)
                {
                    List<IModel> chanels = kvp.Value;
                    foreach (IModel chanel in chanels)
                    {
                        if (chanel != null)
                        {
                            if (chanel.IsOpen)
                                chanel.Close();
                        }
                    }
                }
                _Channels.Clear();
            }

            if (_Connection != null)
            {
                if (_Connection.IsOpen)
                    _Connection.Close();
            }
        }
    }
}
