﻿using DotNet.Utilities;
using DotNet.Utilities.MQ;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DotNet.RabbitMQ
{
    /// <summary>
    /// RabbitMQ 的生产客户端实现。
    /// 
    /// 修改记录
    ///     2017.03.14 版本：1.2    刘海洋 MessageChannel属性增加对Null值的处理。
    ///     2017.01.12 版本：1.1    刘海洋 发送消息时增加 ObjectDisposedException 异常的处理。
    ///     2016.09.29 版本：1.0    刘海洋 初始版本
    ///	
    /// <author>
    ///		<name>刘海洋</name>
    ///		<date>2016.09.29</date>
    /// </author> 
    /// </summary>
    public class RabbitProducerClient : IProducerClient
    {
        private string _ServerAddr = "";
        private int _ServerPort = 0;
        private string _ProducerId = "";
        private string _Topices = "";
        private string _SubExpress = "";
        private string _AccessKey = "";
        private string _SecretKey = "";
        private MessageProcessCallback _MessageProcessCallback = null;

        private ConnectionFactory _Factory = null;
        private IConnection _Connection = null;
        private IModel _Channel = null;
        private object lockObj = new object();

        /// <summary>
        /// 保存所有已有的消息交换机名称。
        /// </summary>
        private ConcurrentBag<string> cbExchangeNames = new ConcurrentBag<string>();

        /// <summary>
        /// 释放资源。
        /// </summary>
        public void Dispose()
        {
            Shutdown();
            if (_Channel != null)
            {
                _Channel.Close();
                _Channel.Dispose();
            }
            if (_Connection != null)
            {
                _Connection.Close();
                _Connection.Dispose();
            }
            _Factory = null;
            _Channel = null;
            _Connection = null;
        }

        public void SetConnectInfo(string serverAddr , int port = 0, string producerId = "", 
            string accessKey = "", string secretKey = "")
        {
            _ServerAddr = serverAddr;
            _ProducerId = producerId;
            _AccessKey = accessKey;
            _SecretKey = secretKey;
            _ServerPort = port;
        }

        /// <summary>
        /// 关闭所有连接，停止接收消息。
        /// </summary>
        public void Shutdown()
        {
            if (_Channel != null)
            {
                if (_Channel.IsOpen)
                    _Channel.Close();

            }

            if (_Connection != null)
            {
                if (_Connection.IsOpen)
                    _Connection.Close();
            }
        }

        /// <summary>
        /// 获取消息的发送通道实例。
        /// </summary>
        public IModel MessageChannel
        {
            get
            {
                if (_Channel == null)
                {
                    lock (lockObj)
                    {
                        if (_Channel == null || _Factory == null || _Connection == null)
                        {
                            if(_Factory == null)
                                _Factory = new ConnectionFactory() { HostName = _ServerAddr, Port = _ServerPort, VirtualHost = _ProducerId, UserName = _AccessKey, Password = _SecretKey };                            
                          
                            //网络连接异常时自动恢复。
                            _Factory.AutomaticRecoveryEnabled = true;
                            //每10秒钟检查一次网络连接。
                            _Factory.NetworkRecoveryInterval = new TimeSpan(0, 0, 10);
                            if (_Connection != null)
                            {
                                _Connection.Close();
                                _Connection.Dispose();
                            }
                            _Connection = _Factory.CreateConnection();
                            if (_Channel != null)
                            {
                                _Channel.Close();
                                _Channel.Dispose();
                            }
                            _Channel = _Connection.CreateModel();
                        }
                    }
                }
                return _Channel;
            }
        }

        /// <summary>
        /// 发送主题类别的消息到服务器，客户端可以根据多级多题（关键字）过滤进行消息订阅。
        /// </summary>
        /// <param name="topic">消息主题。</param>
        /// <param name="filterExpress">消息过滤关键字，依据此关键字决定消息送往不同的队列。。</param>
        /// <param name="message">消息内容。</param>
        /// <param name="msgId">消息的唯一Id。</param>
        /// <param name="expTime">消息有效期（毫秒），默认为三天，超过三天自动删除。</param>
        /// <returns><see cref="MQSendResult"/>。</returns>
        public MQSendResult SendTopicMessage(string topic, string filterExpress, string message,string msgId = "", long expTime = 259200000)
        {
            if(string.IsNullOrEmpty(msgId))
                msgId = Guid.NewGuid().ToString();
            bool sucess = false;
            string exceptionInfo = "";
            try
            {
                if (!cbExchangeNames.Contains(topic))
                {
                    ////定义消息交换机。
                    //MessageChannel.ExchangeDeclare(exchange: topic,
                    //                                type: "topic", durable: true);
                    //每个消费者同一时间最多分发10条消息。
                    MessageChannel.BasicQos(0, 1000, true);
                    cbExchangeNames.Add(topic);
                }

                var routingKey = !string.IsNullOrEmpty(filterExpress) ? filterExpress : topic;
                SendMessage(msgId, message, topic, routingKey, expTime);

                sucess = true;
            }
            catch (Exception ep)
            {
                LogUtilities.WriteException(ep);
                exceptionInfo = ep.Message;
            }

            MQSendResult msr = new MQSendResult(msgId, sucess, exceptionInfo);
            return msr;
        }

        /// <summary>
        /// 发送发布/订阅消类别的消息到服务器，同一个交换机的订阅队列的消息都是相同的。
        /// </summary>
        /// <param name="topic"></param>
        /// <param name="subExpress"></param>
        /// <param name="message"></param>
        /// <param name="msgId"></param>
        /// <param name="expTime">消息有效期（毫秒），默认为三天，超过三天自动删除。</param>
        /// <returns><see cref="MQSendResult"/>。</returns>
        public MQSendResult SendPubSubMessage(string topic, string message, string msgId = "",long expTime = 259200000)
        {
            if (string.IsNullOrEmpty(msgId))
                msgId = Guid.NewGuid().ToString();
            bool sucess = false;
            string exceptionInfo = "";
            try
            {
                if (!cbExchangeNames.Contains(topic))
                {
                    ////定义消息交换机。
                    //MessageChannel.ExchangeDeclare(exchange: topic,
                    //                                type: "fanout", durable: true);
                    cbExchangeNames.Add(topic);
                }

                SendMessage(msgId, message, topic, "", expTime);

                sucess = true;
            }
            catch (ObjectDisposedException ode)
            {                
                LogUtilities.WriteException(ode);
                //如果出现ObjectDisposedException异常，先释放所有资源，然后重新连接。
                if (_Channel != null)
                {
                    _Channel.Close();
                    _Channel.Dispose();
                    _Channel = null;
                }

                if (_Connection != null)
                {
                    _Connection.Close();
                    _Connection.Dispose();
                    _Connection = null;
                }

                _Factory = null;
            }
            catch (Exception ep)
            {
                LogUtilities.WriteLine("发送失败，topic={0}，message={1}，异常={2}", topic, message, ep);
                exceptionInfo = ep.Message;
            }

            MQSendResult msr = new MQSendResult(msgId, sucess, exceptionInfo);
            return msr;
        }

        /// <summary>
        /// 发送消息到指定的交换机。
        /// </summary>
        /// <param name="msgId">消息唯一Id。</param>
        /// <param name="message">消息内容。</param>
        /// <param name="exchangeName">消息交换机名称。</param>
        /// <param name="routingKey">消息路由关键字。</param>
        /// <param name="expTime">消息有效期（毫秒）。</param>
        private void SendMessage(string msgId,string message,string exchangeName,string routingKey, long expTime)
        {
            IBasicProperties bp = MessageChannel.CreateBasicProperties();
            bp.MessageId = msgId;
            bp.DeliveryMode = 2;
            bp.Expiration = expTime.ToString(); //消息过期时间，毫秒。

            var body = Encoding.UTF8.GetBytes(message);
            MessageChannel.BasicPublish(exchange: exchangeName,
                                     routingKey: routingKey,
                                     basicProperties: bp,
                                     body: body);
        }

        public MQSendResult Send<T>(string topic, string subExpress, T message, string msgId = "")
        {
            return Send(topic, subExpress, message.FastToJson(), msgId);
        }
    }
}
